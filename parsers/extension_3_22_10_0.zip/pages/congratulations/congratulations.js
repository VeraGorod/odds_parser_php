define(["./block.js"], function (_block) {
  "use strict";

  // @flow
  document.title = (0, _block.$internationalizeDefault)('you_just_installed_browsec');
});
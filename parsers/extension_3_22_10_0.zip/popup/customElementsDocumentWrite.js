if (!window.customElements) {
  document.write('<!--');
}